import os
import subprocess


class Validator:
    _SPLUNK_HOME_VAR = 'SPLUNK_HOME'
    _JAVA_HOME_VAR = 'JAVA_HOME'

    def is_splunk_home_var_configured(self) -> bool:
        splunk_home = os.getenv(self._SPLUNK_HOME_VAR)

        return (splunk_home is not None) and (os.path.exists(splunk_home))

    def is_java_command_accessible(self) -> bool:
        java_executable = 'java'
        java_home = os.getenv(self._JAVA_HOME_VAR)

        if (java_home is not None) and (os.path.exists(java_home)):
            java_executable = os.path.join(java_home, 'bin', 'java')

        output = subprocess.run(f'{java_executable} --version',
                                shell=True, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)

        return output.returncode == 0
