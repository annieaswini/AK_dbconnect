import splunklib.client as splunk_client
from splunklib.binding import AuthenticationError
from .access_error import AccessError


class SplunkAccess:

    @staticmethod
    def get_token(host, port, username, password) -> str:
        try:
            splunk_service = splunk_client.connect(host=host, port=port,
                                                   username=username,
                                                   password=password)
            response = splunk_service.login()

            return response.token

        except AuthenticationError:
            raise AccessError(reason='Username or password are not correct!')
        except Exception:
            raise AccessError(
                reason=f'Splunk is not available for host: {host} '
                       f'and port: {port}')
