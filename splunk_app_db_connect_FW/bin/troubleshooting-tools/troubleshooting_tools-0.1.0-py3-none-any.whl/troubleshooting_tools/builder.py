from .configurations.input_service import InputService
from .configurations.connection_service import ConnectionService
from .configurations.identity_service import IdentityService
from .connections.connector_gateway import ConnectorGateway
from .configurations.settings_service import SettingsService
from .configurations.http_inputs_service import HttpInputsService
from .configurations.kv_store_service import KvStoreService
from .components.http_event_collector import HttpEventCollector
from .components.connection import Connection
from .components.kv_store import KvStore
from .components.input import Input
from .components.java import Java
from .components.keystore import KeyStore
from .components.search_api import SearchApi
import splunklib.client as splunk_client


class Builder:

    def __init__(self, host=None, port=None, token=None, connector_path=None,
                 jdbc_path=None):
        self._host = host
        self._port = port
        self._token = token
        self._connector_path = connector_path
        self._jdbc_path = jdbc_path

    def build_connector_gateway(self):
        return ConnectorGateway(
            connector_path=self._connector_path, jdbc_path=self._jdbc_path)

    def build_settings_service(self):
        return SettingsService(
            splunk_service=self.build_splunk_service(
                app='splunk_app_db_connect'))

    def build_input_service(self):
        return InputService(
            splunk_service=self.build_splunk_service(
                app='splunk_app_db_connect'))

    def build_http_inputs_service(self):
        return HttpInputsService(
            splunk_service=self.build_splunk_service(
                app='splunk_app_db_connect'))

    def build_kv_store_service(self):
        return KvStoreService(
            splunk_service=self.build_splunk_service(
                app='splunk_app_db_connect'))

    def build_connection_service(self):
        return ConnectionService(
            splunk_service=self.build_splunk_service(
                app='splunk_app_db_connect'))

    def build_identity_service(self):
        return IdentityService(
            splunk_service=self.build_splunk_service(
                app='splunk_app_db_connect'))

    def build_splunk_service(self, app=None):
        if app is not None:
            return splunk_client.connect(host=self._host, port=self._port,
                                         app=app, token=self._token)

        return splunk_client.connect(host=self._host, port=self._port,
                                     token=self._token)

    def build_connection_component(self):
        return Connection(connection_service=self.build_connection_service(),
                          identity_service=self.build_identity_service(),
                          connector_gateway=self.build_connector_gateway())

    def build_http_event_collector_component(self):
        return HttpEventCollector(settings=self.build_settings_service(),
                                  http_inputs_service=self.build_http_inputs_service())

    def build_input_component(self):
        return Input(input_service=self.build_input_service(),
                     connection=self.build_connection_component(),
                     http_event_collector=self.build_http_event_collector_component(),
                     kv_store=self.build_kv_store_component(),
                     kv_store_service=self.build_kv_store_service())

    def build_kv_store_component(self):
        return KvStore(splunk_service=self.build_splunk_service())

    def build_java_component(self):
        return Java(settings=self.build_settings_service())

    @staticmethod
    def build_keystore_component():
        return KeyStore()

    def build_search_api_component(self):
        return SearchApi(splunk_service=self.build_splunk_service())
