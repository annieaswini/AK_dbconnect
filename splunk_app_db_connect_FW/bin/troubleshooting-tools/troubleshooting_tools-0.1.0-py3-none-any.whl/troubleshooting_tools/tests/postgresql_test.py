import unittest
from ..databases.postgresql import PostgreSql
from ..databases.connection_attrs import ConnectionAttrs
from ..databases.database_error import DatabaseError


class PostgreSqlTest(unittest.TestCase):

    def test_should_parse_connection_string(self):
        # given
        connection_string = 'jdbc:postgresql://localhost:5432/postgres?ssl=true&sslmode=require'

        # when
        connection_attrs: ConnectionAttrs = PostgreSql().parse_connection_string(
            connection_string)

        # then
        self.assertEqual('localhost', connection_attrs.host)
        self.assertEqual('5432', connection_attrs.port)
        self.assertEqual('postgres', connection_attrs.database)
        self.assertEqual('true', connection_attrs.ssl)

    def test_should_parse_connection_string_throw_error(self):
        # given
        connection_string = 'jdbc:postgresql://localhost:5432/?ssl=true&sslmode=require'

        # when
        # then
        with self.assertRaises(DatabaseError) as error:
            PostgreSql().parse_connection_string(connection_string)

        self.assertEqual('JDBC URL has an invalid format',
                         error.exception.reason)

    def test_should_get_connection_string(self):
        # given
        connection_attrs = ConnectionAttrs(host='localhost',
                                           port='5432',
                                           database='postgres',
                                           ssl='true')

        # when
        connection_string = PostgreSql().get_connection_string(connection_attrs)

        # then
        self.assertEqual(
            'jdbc:postgresql://localhost:5432/postgres?ssl=true&sslmode=require',
            connection_string)


if __name__ == '__main__':
    unittest.main()
