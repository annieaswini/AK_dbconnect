import unittest
from ..databases.db2 import Db2
from ..databases.connection_attrs import ConnectionAttrs
from ..databases.database_error import DatabaseError


class Db2Test(unittest.TestCase):

    def test_should_parse_connection_string(self):
        # given
        connection_string = 'jdbc:db2://localhost:25000/db'

        # when
        connection_attrs: ConnectionAttrs = Db2().parse_connection_string(
            connection_string)

        # then
        self.assertEqual('localhost', connection_attrs.host)
        self.assertEqual('25000', connection_attrs.port)
        self.assertEqual('db', connection_attrs.database)

    def test_should_parse_connection_string_throw_error(self):
        # given
        connection_string = 'jdbc:db2://localhost:25000'

        # when
        # then
        with self.assertRaises(DatabaseError) as error:
            Db2().parse_connection_string(connection_string)

        self.assertEqual('JDBC URL has an invalid format',
                         error.exception.reason)

    def test_should_get_connection_string(self):
        # given
        connection_attrs = ConnectionAttrs(host='localhost',
                                           port='25000',
                                           database='db')

        # when
        connection_string = Db2().get_connection_string(connection_attrs)

        # then
        self.assertEqual(
            'jdbc:db2://localhost:25000/db',
            connection_string)


if __name__ == '__main__':
    unittest.main()
