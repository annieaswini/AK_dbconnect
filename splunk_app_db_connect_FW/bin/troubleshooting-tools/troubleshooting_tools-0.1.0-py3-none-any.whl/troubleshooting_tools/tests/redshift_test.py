import unittest
from ..databases.redshift import Redshift
from ..databases.connection_attrs import ConnectionAttrs
from ..databases.database_error import DatabaseError


class RedshiftTest(unittest.TestCase):

    def test_should_parse_connection_string(self):
        # given
        connection_string = 'jdbc:redshift://localhost:5439/dev?useSSL=true'

        # when
        connection_attrs: ConnectionAttrs = Redshift().parse_connection_string(
            connection_string)

        # then
        self.assertEqual('localhost', connection_attrs.host)
        self.assertEqual('5439', connection_attrs.port)
        self.assertEqual('dev', connection_attrs.database)
        self.assertEqual('true', connection_attrs.ssl)

    def test_should_parse_connection_string_throw_error(self):
        # given
        connection_string = 'jdbc:redshift://localhost:5439/?useSSL=true'

        # when
        # then
        with self.assertRaises(DatabaseError) as error:
            Redshift().parse_connection_string(connection_string)

        self.assertEqual('JDBC URL has an invalid format',
                         error.exception.reason)

    def test_should_get_connection_string(self):
        # given
        connection_attrs = ConnectionAttrs(host='localhost',
                                           port='5439',
                                           database='dev',
                                           ssl='false')

        # when
        connection_string = Redshift().get_connection_string(connection_attrs)

        # then
        self.assertEqual(
            'jdbc:redshift://localhost:5439/dev?useSSL=false',
            connection_string)


if __name__ == '__main__':
    unittest.main()
