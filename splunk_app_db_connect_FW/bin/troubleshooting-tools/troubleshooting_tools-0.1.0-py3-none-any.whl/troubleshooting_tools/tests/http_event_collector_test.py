import unittest
from unittest import mock
from ..components.http_event_collector import HttpEventCollector
from ..configurations.settings_service import SettingsService
from ..configurations.http_inputs_service import HttpInputsService
from ..components.component_status import ComponentStatus
from ..components.component import Component
from ..configurations.hec_conf import HecConf


def mock_requests_get_ok(*args, **kwargs):
    class Response:
        def __init__(self, data):
            self.data = data

        def json(self):
            return self.data

    return Response({"code": 17})


def mock_requests_post_ok(*args, **kwargs):
    class Response:
        def __init__(self, data):
            self.data = data

        def json(self):
            return self.data

    return Response({"code": 0})


class HttpEventCollectorTest(unittest.TestCase):

    @mock.patch('requests.get', side_effect=mock_requests_get_ok)
    @mock.patch('requests.post', side_effect=mock_requests_post_ok)
    def test_get_status_from_custom_hec(self, mocked_get, mocked_post):
        # given
        settings_service = SettingsService(None)
        hec_conf = HecConf(hosts='https://hec1.com,https://hec2.com',
                           token='0x010101')
        settings_service.get_hec_conf = mock.MagicMock(return_value=hec_conf)

        http_input_service = HttpInputsService(None)

        # when
        status: ComponentStatus = HttpEventCollector(settings_service,
                                                     http_input_service).get_status()

        # then
        self.assertEqual(Component.READY_STATUS, status.status)
        mocked_get.assert_called()
        mocked_post.assert_called()

    @mock.patch('requests.get', side_effect=mock_requests_get_ok)
    @mock.patch('requests.post', side_effect=mock_requests_post_ok)
    def test_get_status_from_local_hec_ready(self, mocked_get, mocked_post):
        # given
        settings_service = SettingsService(None)
        settings_service.get_hec_conf = mock.MagicMock(return_value=HecConf())

        http_input_service = HttpInputsService(None)
        hec_conf = HecConf(port=8086, token='0x010101', disabled='0')
        http_input_service.get_global_hec_conf = mock.MagicMock(
            return_value=hec_conf)
        http_input_service.get_hec_token_conf = mock.MagicMock(
            return_value=hec_conf)

        # when
        status: ComponentStatus = HttpEventCollector(settings_service,
                                                     http_input_service).get_status()

        # then
        self.assertEqual(Component.READY_STATUS, status.status)
        mocked_get.assert_called()
        mocked_post.assert_called()

    @mock.patch('requests.get', side_effect=mock_requests_get_ok)
    @mock.patch('requests.post', side_effect=mock_requests_post_ok)
    def test_get_status_from_local_hec_failed_because_disabled(self, mocked_get,
                                                               mocked_post):
        # given
        settings_service = SettingsService(None)
        settings_service.get_hec_conf = mock.MagicMock(return_value=HecConf())

        http_input_service = HttpInputsService(None)
        hec_conf = HecConf(port=8086, token='0x010101', disabled='1')
        http_input_service.get_global_hec_conf = mock.MagicMock(
            return_value=hec_conf)
        http_input_service.get_hec_token_conf = mock.MagicMock(
            return_value=hec_conf)

        # when
        status: ComponentStatus = HttpEventCollector(settings_service,
                                                     http_input_service).get_status()

        # then
        self.assertEqual(Component.FAILED_STATUS, status.status)
        mocked_get.assert_not_called()
        mocked_post.assert_not_called()


if __name__ == '__main__':
    unittest.main()
