import unittest
from ..databases.snowflake import Snowflake
from ..databases.connection_attrs import ConnectionAttrs
from ..databases.database_error import DatabaseError


class SnowflakeTest(unittest.TestCase):

    def test_should_parse_connection_string(self):
        # given
        connection_string = 'jdbc:snowflake://localhost:443?db=IT_DB&warehouse=IT_WAREHOUSE'

        # when
        connection_attrs: ConnectionAttrs = Snowflake().parse_connection_string(
            connection_string)

        # then
        self.assertEqual('localhost', connection_attrs.host)
        self.assertEqual('443', connection_attrs.port)
        self.assertEqual('IT_DB', connection_attrs.database)
        self.assertEqual('IT_WAREHOUSE', connection_attrs.warehouse)

    def test_should_parse_connection_string_throw_error(self):
        # given
        connection_string = 'jdbc:snowflake://localhost:443?warehouse=IT_WAREHOUSE'

        # when
        # then
        with self.assertRaises(DatabaseError) as error:
            Snowflake().parse_connection_string(connection_string)

        self.assertEqual('It seems db or warehouse properties are missed!',
                         error.exception.reason)

    def test_should_get_connection_string(self):
        # given
        connection_attrs = ConnectionAttrs(host='localhost',
                                           port='443',
                                           database='IT_DB',
                                           warehouse='IT_WAREHOUSE')

        # when
        connection_string = Snowflake().get_connection_string(connection_attrs)

        # then
        self.assertEqual(
            'jdbc:snowflake://localhost:443?db=IT_DB&warehouse=IT_WAREHOUSE',
            connection_string)

    def test_should_parse_connection_string_default_port(self):
        # given
        connection_string = 'jdbc:snowflake://localhost?db=IT_DB&warehouse=IT_WAREHOUSE'

        # when
        connection_attrs: ConnectionAttrs = Snowflake().parse_connection_string(
            connection_string)

        # then
        self.assertEqual('localhost', connection_attrs.host)
        self.assertEqual('443', connection_attrs.port)
        self.assertEqual('IT_DB', connection_attrs.database)
        self.assertEqual('IT_WAREHOUSE', connection_attrs.warehouse)


if __name__ == '__main__':
    unittest.main()
