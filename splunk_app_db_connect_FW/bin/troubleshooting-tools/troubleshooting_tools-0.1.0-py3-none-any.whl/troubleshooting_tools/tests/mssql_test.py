import unittest
from ..databases.mssql import MsSql
from ..databases.connection_attrs import ConnectionAttrs
from ..databases.database_error import DatabaseError


class MsSqlTest(unittest.TestCase):

    def test_should_parse_connection_string(self):
        # given
        connection_string = 'jdbc:sqlserver://localhost:1433;databaseName=master;selectMethod=cursor;encrypt=false'

        # when
        connection_attrs: ConnectionAttrs = MsSql().parse_connection_string(
            connection_string)

        # then
        self.assertEqual('localhost', connection_attrs.host)
        self.assertEqual('1433', connection_attrs.port)
        self.assertEqual('master', connection_attrs.database)
        self.assertEqual('false', connection_attrs.ssl)

    def test_should_parse_connection_string_throw_error(self):
        # given
        connection_string = 'jdbc:sqlserver://localhost:1433;master;selectMethod=cursor;encrypt=false'

        # when
        # then
        with self.assertRaises(DatabaseError) as error:
            MsSql().parse_connection_string(connection_string)

        self.assertEqual('It seems databaseName property is missed!',
                         error.exception.reason)

    def test_should_get_connection_string(self):
        # given
        connection_attrs = ConnectionAttrs(host='localhost',
                                           port='1433',
                                           database='master',
                                           ssl='false')

        # when
        connection_string = MsSql().get_connection_string(connection_attrs)

        # then
        self.assertEqual(
            'jdbc:sqlserver://localhost:1433;databaseName=master;selectMethod=cursor;encrypt=false',
            connection_string)


if __name__ == '__main__':
    unittest.main()
