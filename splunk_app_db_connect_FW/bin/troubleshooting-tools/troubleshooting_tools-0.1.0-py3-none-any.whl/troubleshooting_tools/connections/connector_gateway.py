import subprocess
from .connection_response import ConnectionResponse


class ConnectorGateway:

    def __init__(self, connector_path, jdbc_path):
        self._connector_path = connector_path
        self._jdbc_path = jdbc_path

    def establish_connection(self, jdbc_connection, username,
                             password) -> ConnectionResponse:
        output = subprocess.run(f"java -jar '{self._connector_path}' "
                                f"-u='{username}' "
                                f"-p='{password}' "
                                f"-c='{jdbc_connection}' "
                                f"-d='{self._jdbc_path}'",
                                shell=True, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)

        if output.returncode == 0:
            return ConnectionResponse(success=True)
        else:
            return ConnectionResponse(success=False,
                                      message=output.stderr.decode())
