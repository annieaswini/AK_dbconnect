class ConnectionResponse:

    def __init__(self, success: bool, message: str = None):
        self.success = success
        self.message = message
