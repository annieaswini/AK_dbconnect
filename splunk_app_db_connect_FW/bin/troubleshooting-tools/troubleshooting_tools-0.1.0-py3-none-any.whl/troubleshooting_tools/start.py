#!/usr/bin/env python

from .tools.troubleshoot_starts import TroubleshootStarts
from .tools.troubleshoot_connections import TroubleshootConnections
from .tools.troubleshoot_inputs import TroubleshootInputs
from .tools.services_status import ServicesStatus
from .configurations.splunk_settings_service import SplunkSettingsService
from .builder import Builder
from .splunk_access import SplunkAccess
from .access_error import AccessError
from .validator import Validator
import getpass
import sys

_SPLUNK_DEFAULT_URL = 'localhost'
_SPLUNK_DEFAULT_USERNAME = 'admin'


def run():
    _display_header()

    tool_choice = str(input(
        '''Which tool do you want to use?
        1. Troubleshoot Starts
        2. Services Status
        3. Troubleshoot Connections
        4. Troubleshoot Inputs
        : '''))

    if tool_choice == '1':
        _troubleshoot_starts()
    elif tool_choice == '2':
        _services_status()
    elif tool_choice == '3':
        _troubleshoot_connections()
    elif tool_choice == '4':
        _troubleshoot_inputs()


def _troubleshoot_starts():
    print('Troubleshoot Starts')

    _validate_splunk_home()

    host, port, username, password = _read_splunk_settings()

    token = _authenticate(host, port, username, password)

    builder = Builder(host=host, port=port, token=token)

    TroubleshootStarts(kv_store=builder.build_kv_store_component(),
                       java=builder.build_java_component(),
                       keystore=builder.build_keystore_component()).troubleshoot()


def _services_status():
    print('Services Status')

    _validate_splunk_home()

    host, port, username, password = _read_splunk_settings()

    token = _authenticate(host, port, username, password)

    builder = Builder(host=host, port=port, token=token)

    ServicesStatus(kv_store=builder.build_kv_store_component(),
                   keystore=builder.build_keystore_component(),
                   http_event_collector=builder.build_http_event_collector_component(),
                   search_api=builder.build_search_api_component()).troubleshoot()


def _troubleshoot_connections():
    print('Troubleshoot Connections')

    _validate_splunk_home()
    _validate_java_command()

    host, port, username, password = _read_splunk_settings()

    connection_name = str(input('Connection name: '))
    if not connection_name:
        print('Connection name must be provided. The program will finish.')
        sys.exit()

    connector_path, jdbc_path = _read_database_libraries()

    token = _authenticate(host, port, username, password)

    builder = Builder(host=host, port=port, token=token,
                      connector_path=connector_path, jdbc_path=jdbc_path)

    TroubleshootConnections(
        connection=builder.build_connection_component()).troubleshoot(
        connection_name=connection_name)


def _troubleshoot_inputs():
    print('Troubleshoot Inputs')

    _validate_splunk_home()
    _validate_java_command()

    host, port, username, password = _read_splunk_settings()

    input_name = str(input('Input name: '))
    if not input_name:
        print('Input name must be provided. The program will finish.')
        sys.exit()

    connector_path, jdbc_path = _read_database_libraries()

    token = _authenticate(host, port, username, password)

    builder = Builder(host=host, port=port, token=token,
                      connector_path=connector_path, jdbc_path=jdbc_path)

    TroubleshootInputs(
        input_component=builder.build_input_component()).troubleshoot(
        input_name=input_name)


def _read_database_libraries():
    connector_path = str(input('Connector path: '))
    if not connector_path:
        print('Connector path must be provided. The program will finish.')
        sys.exit()

    jdbc_path = str(input('JDBC path: '))
    if not jdbc_path:
        print('JDBC path must be provided. The program will finish.')
        sys.exit()

    return connector_path, jdbc_path


def _read_splunk_settings():
    host = _SPLUNK_DEFAULT_URL
    print(f'Splunk URL: {host}')

    port = SplunkSettingsService().get_management_port()
    print(f'Splunk management port: {port}')

    username = str(input('Splunk username (Default value is <admin>): '))
    if not username:
        username = _SPLUNK_DEFAULT_USERNAME
    print(username)

    password = getpass.getpass('Splunk password: ')
    print('*' * len(password))

    return host, port, username, password


def _authenticate(host, port, username, password):
    try:
        return SplunkAccess().get_token(host=host, port=port, username=username,
                                        password=password)
    except AccessError as error:
        print(error.reason)
        sys.exit()


def _validate_splunk_home():
    if not Validator().is_splunk_home_var_configured():
        print('The splunk home directory is not accessible. Please make sure '
              'SPLUNK_HOME environment variable is setup correctly.')
        sys.exit()


def _validate_java_command():
    if not Validator().is_java_command_accessible():
        print('Java is not configured. Please make sure JRE 11+ is installed '
              'and JAVA_HOME environment variable is setup correctly. ')
        sys.exit()


def _display_header():
    print('|----|----|----|----|----|')
    print('|       DB Connect       |')
    print('| Troubleshooting Tools  |')
    print('|----|----|----|----|----|')


if __name__ == '__main__':
    run()
