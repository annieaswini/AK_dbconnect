from .resolutions.resolution import Resolution


class Display:
    _DOCUMENTATION_RESOLUTION = 'See the documentation for more details'

    def __init__(self):
        self._resolution = Resolution()

    def display_failed_status(self, name, reason, error_message):
        print(f'reason = {reason}')

        if error_message is not None:
            print(f'error_message = {error_message}')

        resolution = self._resolution.get_resolution(name, reason)
        print(f'resolution = {resolution}')
        documentation = self._resolution.get_resolution(name,
                                                        self._DOCUMENTATION_RESOLUTION)

        if documentation:
            print(f'docs = {documentation}')
