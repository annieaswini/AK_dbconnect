from .troubleshoot import Troubleshoot
from ..components.component import Component
from ..components.component_status import ComponentStatus
from ..components.http_event_collector import HttpEventCollector
from ..components.kv_store import KvStore
from ..components.keystore import KeyStore
from ..components.search_api import SearchApi
from ..display import Display


class ServicesStatus(Troubleshoot):

    def __init__(self, kv_store: KvStore, keystore: KeyStore,
                 http_event_collector: HttpEventCollector,
                 search_api: SearchApi):
        self._kv_store = kv_store
        self._keystore = keystore
        self._http_event_collector = http_event_collector
        self._search_api = search_api

    def troubleshoot(self):
        kv_store_status = self._kv_store.get_status()
        keystore_status = self._keystore.get_status()
        hec_status = self._http_event_collector.get_status()
        search_api_status = self._search_api.get_status()

        print('>->->->->->->->->->->->->->')

        self._display('KV Store', kv_store_status)
        self._display('Keystore', keystore_status)
        self._display('HEC', hec_status)
        self._display('Search API', search_api_status)

        print('<-<-<-<-<-<-<-<-<-<-<-<-<-<')

    @staticmethod
    def _display(name, component_status: ComponentStatus):
        print('')
        print(f'[{name}]')
        print(f'status = {component_status.status}')

        if component_status.status == Component.FAILED_STATUS:
            Display().display_failed_status(name,
                                            component_status.reason,
                                            component_status.error_message)
