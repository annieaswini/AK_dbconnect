from .troubleshoot import Troubleshoot
from ..components.component import Component
from ..components.component_status import ComponentStatus
from ..components.input import Input
from ..display import Display


class TroubleshootInputs(Troubleshoot):

    def __init__(self, input_component: Input):
        self._input = input_component

    def troubleshoot(self, **kwargs):
        input_name = kwargs.get('input_name')
        input_status = self._input.get_status(input_name=input_name)

        print('>->->->->->->->->->->->->->')

        self._display(input_name, input_status)

        print('<-<-<-<-<-<-<-<-<-<-<-<-<-<')

    @staticmethod
    def _display(input_name, input_status: ComponentStatus):
        print(f'[{input_name}]')
        print(f'status = {input_status.status}')

        if input_status.status == Component.FAILED_STATUS:
            Display().display_failed_status('Input',
                                            input_status.reason,
                                            input_status.error_message)
