from .troubleshoot import Troubleshoot
from ..components.component import Component
from ..components.component_status import ComponentStatus
from ..components.connection import Connection
from ..display import Display


class TroubleshootConnections(Troubleshoot):

    def __init__(self, connection: Connection):
        self._connection = connection

    def troubleshoot(self, **kwargs):
        connection_name = kwargs.get('connection_name')
        connection_status = self._connection.get_status(
            connection_name=connection_name)

        print('>->->->->->->->->->->->->->')

        self._display(connection_name, connection_status)

        print('<-<-<-<-<-<-<-<-<-<-<-<-<-<')

    @staticmethod
    def _display(connection_name, connection_status: ComponentStatus):
        print(f'[{connection_name}]')
        print(f'status = {connection_status.status}')

        if connection_status.status == Component.FAILED_STATUS:
            Display().display_failed_status('Database Connection',
                                            connection_status.reason,
                                            connection_status.error_message)
