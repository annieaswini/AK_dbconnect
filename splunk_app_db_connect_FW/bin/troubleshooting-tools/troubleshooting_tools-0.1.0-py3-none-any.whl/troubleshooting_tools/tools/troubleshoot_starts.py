from typing import List

from .troubleshoot import Troubleshoot
from ..components.component import Component
from ..components.component_status import ComponentStatus
from ..components.java import Java
from ..components.keystore import KeyStore
from ..components.kv_store import KvStore
from ..display import Display


class TroubleshootStarts(Troubleshoot):

    def __init__(self, kv_store: KvStore, java: Java, keystore: KeyStore):
        self._kv_store = kv_store
        self._java = java
        self._keystore = keystore

    def troubleshoot(self):
        java_status = self._java.get_status()
        kv_store_status = self._kv_store.get_status()
        keystore_status = self._keystore.get_status()

        print('>->->->->->->->->->->->->->')

        self._display_global_status(
            [java_status, kv_store_status, keystore_status])
        self._display('Java', java_status)
        self._display('KV Store', kv_store_status)
        self._display('Keystore', keystore_status)

        print('<-<-<-<-<-<-<-<-<-<-<-<-<-<')

    @staticmethod
    def _display(name, component_status: ComponentStatus):
        print('')
        print(f'[{name}]')
        print(f'status = {component_status.status}')

        if component_status.status == Component.FAILED_STATUS:
            Display().display_failed_status(name,
                                            component_status.reason,
                                            component_status.error_message)

    @staticmethod
    def _display_global_status(components: List[ComponentStatus]):
        components_with_failures = filter(
            lambda component: component.status == Component.FAILED_STATUS,
            components)

        if len(list(components_with_failures)) > 0:
            print(f'DB Connect: {Component.FAILED_STATUS}')
        else:
            print(f'DB Connect: {Component.READY_STATUS}')
