from abc import ABC, abstractmethod


class Troubleshoot(ABC):

    @abstractmethod
    def troubleshoot(self, **kwargs):
        raise NotImplementedError
