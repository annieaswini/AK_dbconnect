import socket
from contextlib import closing


class Network:

    @staticmethod
    def is_reachable(host, port) -> bool:
        with closing(socket.socket(socket.AF_INET,
                                   socket.SOCK_STREAM)) as closing_socket:
            closing_socket.settimeout(8)

            if closing_socket.connect_ex((host, int(port))) == 0:
                return True
            else:
                return False

    @staticmethod
    def is_localhost(url) -> bool:
        return ('localhost' in url) | ('127.0.0.1' in url)
