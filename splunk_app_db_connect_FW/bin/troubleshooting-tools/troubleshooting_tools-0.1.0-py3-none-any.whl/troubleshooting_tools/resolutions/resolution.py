import os
import configparser
from configparser import ConfigParser
from typing import Optional


class Resolution:
    _RESOLUTION_FILE = 'resolutions.ini'

    def __init__(self):
        self._config = ConfigParser()
        self._config.read(
            os.path.join(os.path.dirname(__file__), self._RESOLUTION_FILE))

    def get_resolution(self, component, reason) -> Optional[str]:
        try:
            return self._config.get(component, reason)
        except (configparser.NoOptionError, configparser.NoSectionError):
            return None
