import re

from .database import Database
from .connection_attrs import ConnectionAttrs
from .database_error import DatabaseError


class MsSql(Database):
    _CONNECTION_STRING_TEMPLATE = 'jdbc:sqlserver://{0}:{1};databaseName={2};selectMethod=cursor;encrypt={3}'
    _PROTOCOL_GROUP = r'(jdbc:sqlserver:\/\/)'
    _HOST_GROUP = r'([A-Za-z0-9\w.-]+)'
    _PORT_GROUP = r'([0-9]+)'
    _PARAMS_GROUP = r'((?:;[A-Za-z0-9\w-]+=[A-Za-z0-9\w-]+)+)?'
    _CONNECTION_STRING_PATTERN = f'{_PROTOCOL_GROUP}{_HOST_GROUP}:{_PORT_GROUP}{_PARAMS_GROUP}'

    def get_connection_string(self, connection_attrs: ConnectionAttrs) -> str:
        return self._CONNECTION_STRING_TEMPLATE.format(connection_attrs.host,
                                                       connection_attrs.port,
                                                       connection_attrs.database,
                                                       connection_attrs.ssl)

    def parse_connection_string(self,
                                connection_string: str) -> ConnectionAttrs:
        match = re.search(self._CONNECTION_STRING_PATTERN, connection_string)

        if match is not None:
            host = match.group(2)
            port = match.group(3)
            params = match.group(4)

            connection_params = self._get_connection_params(params, None, ';')
            database = connection_params.get('databaseName')
            ssl = connection_params.get('encrypt')

            if database is None:
                raise DatabaseError(
                    reason='It seems databaseName property is missed!')

            if ssl is None:
                ssl = 'false'

            return ConnectionAttrs(host=host, port=port, database=database,
                                   ssl=ssl)
        else:
            raise DatabaseError(reason='JDBC URL has an invalid format')
