from abc import ABC

from ..components.component_status import ComponentStatus
from ..components.component import Component
from .database_error import DatabaseError
from ..security.certificate_error import CertificateError
from ..network.network import Network
from ..security.certificate import CertificateValidator
from .connection_attrs import ConnectionAttrs


class Database(ABC):
    _UNKNOWN_REASON = 'Unknown'

    def __init__(self, connector_gateway=None):
        self._connector_gateway = connector_gateway

    def get_status(self, connection_conf, identity_conf):
        try:
            connection_attrs: ConnectionAttrs = self._get_connection_settings(
                connection_conf)
            self._validate_server_is_reachable(connection_attrs.host,
                                               connection_attrs.port)

            if connection_conf.jdbc_use_ssl:
                self._validate_certificate_is_not_expired(
                    connection_conf.certificate)

            return self._get_status(connection_attrs,
                                    identity_conf.username,
                                    identity_conf.password)

        except (DatabaseError, CertificateError) as error:
            return ComponentStatus(status=Component.FAILED_STATUS,
                                   reason=error.reason,
                                   error_message=error.message)

    def parse_connection_string(self, connection_string) -> ConnectionAttrs:
        raise NotImplementedError

    def get_connection_string(self, connection_attrs: ConnectionAttrs) -> str:
        raise NotImplementedError

    def _get_connection_settings(self, connection_conf):
        host = connection_conf.host
        port = connection_conf.port
        database = connection_conf.database

        if connection_conf.customized_jdbc_url:
            return self.parse_connection_string(
                connection_conf.customized_jdbc_url)

        return ConnectionAttrs(host=host, port=port, database=database)

    @staticmethod
    def _validate_server_is_reachable(host, port):
        if not Network.is_reachable(host, port):
            raise DatabaseError(reason='Server is not reachable')

    @staticmethod
    def _validate_certificate_is_not_expired(certificate):
        if certificate is not None:
            CertificateValidator.validate(certificate)

    def _get_status(self, connection_attrs: ConnectionAttrs,
                    username, password):
        jdbc_connection = self.get_connection_string(connection_attrs)
        connection_response = self._connector_gateway.establish_connection(
            jdbc_connection=jdbc_connection,
            username=username,
            password=password)

        if connection_response.success:
            return ComponentStatus(status=Component.READY_STATUS)
        else:
            return ComponentStatus(status=Component.FAILED_STATUS,
                                   reason=self._UNKNOWN_REASON,
                                   error_message=connection_response.message)

    @staticmethod
    def _get_connection_params(first_param, others_params, separator):
        params = None
        connection_params = dict()

        if first_param is not None:
            first_param = first_param.replace('?', '')
            params = first_param

        if others_params is not None:
            params = params + others_params

        if params is not None:
            for entry in params.split(separator):
                if entry != '':
                    pair = entry.split('=')
                    key = pair[0]
                    value = pair[1]
                    connection_params[key] = value

        return connection_params
