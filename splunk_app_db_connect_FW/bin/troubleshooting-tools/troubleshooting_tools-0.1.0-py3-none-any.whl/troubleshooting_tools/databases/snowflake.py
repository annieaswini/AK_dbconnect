import re

from .database import Database
from .connection_attrs import ConnectionAttrs
from .database_error import DatabaseError


class Snowflake(Database):
    _DEFAULT_PORT = '443'
    _CONNECTION_STRING_TEMPLATE = 'jdbc:snowflake://{0}:{1}?db={2}&warehouse={3}'
    _PROTOCOL_GROUP = r'(jdbc:snowflake:\/\/)'
    _HOST_GROUP = r'([A-Za-z0-9\w.-]+)'
    _PORT_GROUP = r'(?::([0-9]+)?)?'
    _FIRST_PARAMS_GROUP = r'(\?[A-Za-z0-9\w-]+=[A-Za-z0-9\w-]+)'
    _OTHERS_PARAMS_GROUP = r'((?:&[A-Za-z0-9\w-]+=[A-Za-z0-9\w-]+)+)?'
    _CONNECTION_STRING_PATTERN = f'{_PROTOCOL_GROUP}{_HOST_GROUP}{_PORT_GROUP}/?{_FIRST_PARAMS_GROUP}{_OTHERS_PARAMS_GROUP}'

    def get_connection_string(self, connection_attrs: ConnectionAttrs) -> str:
        return self._CONNECTION_STRING_TEMPLATE.format(connection_attrs.host,
                                                       connection_attrs.port,
                                                       connection_attrs.database,
                                                       connection_attrs.warehouse)

    def parse_connection_string(self,
                                connection_string: str) -> ConnectionAttrs:
        match = re.search(self._CONNECTION_STRING_PATTERN, connection_string)
        port = self._DEFAULT_PORT

        if match is not None:
            host = match.group(2)

            if match.group(3) is not None:
                port = match.group(3)

            first_param = match.group(4)
            others_params = match.group(5)

            connection_params = self._get_connection_params(first_param,
                                                            others_params, '&')

            database = connection_params.get('db')
            warehouse = connection_params.get('warehouse')

            if (database is None) | (warehouse is None):
                raise DatabaseError(
                    reason='It seems db or warehouse properties are missed!')

            return ConnectionAttrs(host=host, port=port,
                                   database=database,
                                   warehouse=warehouse)
        else:
            raise DatabaseError(reason='JDBC URL has an invalid format')
