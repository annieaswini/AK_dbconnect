class ConnectionAttrs:

    def __init__(self, host=None, port=None, database=None, warehouse=None,
                 ssl=None):
        self.host = host
        self.port = port
        self.database = database
        self.warehouse = warehouse
        self.ssl = ssl

