import re

from .database import Database
from .database_error import DatabaseError
from .connection_attrs import ConnectionAttrs


class Redshift(Database):
    _CONNECTION_STRING_TEMPLATE = 'jdbc:redshift://{0}:{1}/{2}?useSSL={3}'
    _PROTOCOL_GROUP = r'(jdbc:redshift:\/\/)'
    _HOST_GROUP = r'([A-Za-z0-9\w.-]+)'
    _PORT_GROUP = r'([0-9]+)'
    _DATABASE_GROUP = r'([A-Za-z0-9\w-]+)'
    _FIRST_PARAMS_GROUP = r'(\?[A-Za-z0-9\w-]+=[A-Za-z0-9\w-]+)'
    _OTHERS_PARAMS_GROUP = r'((?:&[A-Za-z0-9\w-]+=[A-Za-z0-9\w-]+)+)?'
    _CONNECTION_STRING_PATTERN = f'{_PROTOCOL_GROUP}{_HOST_GROUP}:{_PORT_GROUP}/{_DATABASE_GROUP}{_FIRST_PARAMS_GROUP}{_OTHERS_PARAMS_GROUP}'

    def get_connection_string(self, connection_attrs: ConnectionAttrs) -> str:
        return self._CONNECTION_STRING_TEMPLATE.format(connection_attrs.host,
                                                       connection_attrs.port,
                                                       connection_attrs.database,
                                                       connection_attrs.ssl)

    def parse_connection_string(self,
                                connection_string: str) -> ConnectionAttrs:
        match = re.search(self._CONNECTION_STRING_PATTERN, connection_string)

        if match is not None:
            host = match.group(2)
            port = match.group(3)
            database = match.group(4)
            first_param = match.group(5)
            others_params = match.group(6)

            connection_params = self._get_connection_params(first_param,
                                                            others_params, '&')
            use_ssl = connection_params.get('useSSL')

            if use_ssl is None:
                use_ssl = 'false'

            return ConnectionAttrs(host=host, port=port, database=database,
                                   ssl=use_ssl)
        else:
            raise DatabaseError(reason='JDBC URL has an invalid format')
