import OpenSSL
from datetime import datetime
from .certificate_error import CertificateError


class CertificateValidator:

    @staticmethod
    def validate(certificate):
        certificate_x509 = OpenSSL.crypto.load_certificate(
            OpenSSL.crypto.FILETYPE_PEM,
            certificate)
        expiration_date = datetime.strptime(
            certificate_x509.get_notAfter().decode(), '%Y%m%d%H%M%SZ')

        if certificate_x509.has_expired():
            raise CertificateError(reason='Certificate has expired!',
                                   message=f'Certificate has expired!'
                                           f' Expiration date: {expiration_date}')
