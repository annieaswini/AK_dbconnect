from base64 import b64decode
from Crypto.Cipher import AES
from Crypto.Hash import MD5
from Crypto.Util.Padding import unpad


class Cipher:

    @staticmethod
    def decrypt(encrypted_text: str, passphrase: str) -> str:
        passphrase_in_bytes = bytes(passphrase, 'utf-8')
        encrypted_text_in_bytes = b64decode(encrypted_text)
        salt = encrypted_text_in_bytes[8:16]
        hash_1 = MD5.new(passphrase_in_bytes + salt).digest()
        hash_2 = MD5.new(hash_1 + passphrase_in_bytes + salt).digest()
        iv = MD5.new(hash_2 + passphrase_in_bytes + salt).digest()
        key = hash_1 + hash_2

        aes = AES.new(key, AES.MODE_CBC, iv)
        decrypted_text_in_bytes = unpad(
            aes.decrypt(encrypted_text_in_bytes[16:]), AES.block_size)

        return decrypted_text_in_bytes.decode()
