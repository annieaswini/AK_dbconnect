import os
from .cipher import Cipher


class Security:
    _SPLUNK_HOME_VAR = 'SPLUNK_HOME'
    _DB_CONNECT_HOME = os.path.join('etc', 'apps', 'splunk_app_db_connect')
    _PASSPHRASE_FILE = os.path.join('certs', 'identity.dat')

    def decrypt(self, password) -> str:
        passphrase = self._get_passphrase()
        return self._decrypt_password(password, passphrase)

    def _get_passphrase(self) -> str:
        splunk_home = os.getenv(self._SPLUNK_HOME_VAR)
        passphrase_path = os.path.join(splunk_home, self._DB_CONNECT_HOME,
                                       self._PASSPHRASE_FILE)
        passphrase_file = open(passphrase_path, 'r')
        passphrase = passphrase_file.readline()

        return passphrase

    @staticmethod
    def _decrypt_password(password, passphrase) -> str:
        return Cipher.decrypt(password, passphrase)
