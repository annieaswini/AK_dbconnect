from typing import List
from .component import Component
from .component_status import ComponentStatus
from ..configurations.settings_service import SettingsService
from ..configurations.http_inputs_service import HttpInputsService
from ..configurations.hec_conf import HecConf
from ..configurations.configuration_error import ConfigurationError
from ..components.hec_error import HecError
from ..network.network import Network
import requests
import urllib3

urllib3.disable_warnings()


class HttpEventCollector(Component):
    _LOCAL_HEC_API = 'https://localhost:{0}'

    def __init__(self, settings: SettingsService,
                 http_inputs_service: HttpInputsService):
        self._settings = settings
        self._http_inputs_service = http_inputs_service

    def get_status(self) -> ComponentStatus:
        hec_conf: HecConf = self._settings.get_hec_conf()

        try:
            if (hec_conf.hosts is not None) & (hec_conf.token is not None):
                statuses = self._get_status_from_custom_hec(hec_conf)
            else:
                statuses = self._get_status_from_local_hec()

        except (HecError, ConfigurationError) as error:
            return ComponentStatus(status=self.FAILED_STATUS,
                                   reason=error.reason,
                                   error_message=error.message)

        return self._get_global_status(statuses)

    def _get_status_from_custom_hec(self, hec_conf: HecConf) -> []:
        statuses = list()
        hosts = hec_conf.hosts.split(',')
        tokens = hec_conf.token.split(',')
        has_token_per_host = len(hosts) == len(tokens)

        for index, host in enumerate(hosts):
            token = tokens[0]
            if has_token_per_host:
                token = tokens[index]
            hec_status = self._get_status(host, token)
            statuses.append(hec_status)

        return statuses

    def _get_status_from_local_hec(self) -> []:
        global_hec_conf: HecConf = self._http_inputs_service.get_global_hec_conf()
        self._validate_global_hec_is_enabled(global_hec_conf)

        hec_token_conf: HecConf = self._http_inputs_service.get_hec_token_conf()
        self._validate_hec_token_is_enabled(hec_token_conf)

        port = global_hec_conf.port
        token = hec_token_conf.token
        hec_status = self._get_status(self._LOCAL_HEC_API.format(port),
                                      token)
        return [hec_status]

    def _get_global_status(self, statuses: List[ComponentStatus]):
        hec_with_failures = list(filter(
            lambda component: component.status == Component.FAILED_STATUS,
            statuses))
        if len(hec_with_failures) > 0:
            reason = ''
            error_message = ''
            for hec in hec_with_failures:
                reason = hec.reason
                error_message += f'{hec.error_message}; '

            return ComponentStatus(status=self.FAILED_STATUS,
                                   reason=reason, error_message=error_message)

        return ComponentStatus(status=self.READY_STATUS)

    def _get_status(self, hec_url, token):
        verify_ssl = not Network.is_localhost(hec_url)
        health_api = f'{hec_url}/services/collector/health'

        try:
            health_api_response = requests.get(health_api,
                                               verify=verify_ssl).json()

            health_api_code = health_api_response.get('code')
            if health_api_code != 17:  # HEC is not healthy
                return ComponentStatus(status=self.FAILED_STATUS,
                                       reason='HEC is unhealthy',
                                       error_message=f'HEC {hec_url} is unhealthy')

            event_api = f'{hec_url}/services/collector/event'
            event_api_response = requests.post(event_api,
                                               headers={
                                                   'Authorization': f'Splunk {token}'
                                               },
                                               data='{"event": "HEC status is UP"}',
                                               verify=verify_ssl).json()

            event_api_code = event_api_response.get('code')
            if event_api_code != 0:  # HEC could not handle the request
                return ComponentStatus(status=self.FAILED_STATUS,
                                       reason='HEC is unable to process requests',
                                       error_message=f'HEC {hec_url} is unable '
                                                     f'to process requests')
        except Exception as error:
            return ComponentStatus(status=self.FAILED_STATUS,
                                   reason='HEC is unable to process requests',
                                   error_message=error)

        return ComponentStatus(status=self.READY_STATUS)

    @staticmethod
    def _validate_global_hec_is_enabled(global_hec_conf: HecConf):
        if global_hec_conf.disabled == '1':
            raise HecError(reason='Global HEC is disabled')

    @staticmethod
    def _validate_hec_token_is_enabled(hec_token_conf: HecConf):
        if hec_token_conf.disabled == '1':
            raise HecError(reason='HEC token is disabled',
                           message=f'HEC token {hec_token_conf.token} '
                                   f'is disabled')
