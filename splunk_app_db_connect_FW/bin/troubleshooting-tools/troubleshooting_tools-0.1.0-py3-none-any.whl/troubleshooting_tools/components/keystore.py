import os
import jks
from .component import Component
from .component_status import ComponentStatus
from ..security.security import Security


class KeyStore(Component):
    _SPLUNK_HOME_VAR = 'SPLUNK_HOME'
    _DB_CONNECT_HOME = os.path.join('etc', 'apps', 'splunk_app_db_connect')
    _KEYSTORE_FILE = os.path.join('keystore', 'default.jks')
    _PASSPHRASE_FILE = os.path.join('certs', 'identity.dat')
    _KEYSTORE_PASSWORD_FILE = os.path.join('certs', 'keystore_password.dat')

    def get_status(self) -> ComponentStatus:
        splunk_home = os.getenv(self._SPLUNK_HOME_VAR)
        keystore_path = os.path.join(splunk_home, self._DB_CONNECT_HOME,
                                     self._KEYSTORE_FILE)
        keystore_password_path = os.path.join(splunk_home,
                                              self._DB_CONNECT_HOME,
                                              self._KEYSTORE_PASSWORD_FILE)

        keystore_exists = os.path.exists(keystore_path)
        keystore_password_exists = os.path.exists(keystore_password_path)

        if not keystore_exists:
            return ComponentStatus(self.FAILED_STATUS,
                                   reason='Keystore file does not exist',
                                   error_message=f'File {keystore_path}'
                                                 f' does not exists')

        if not keystore_password_exists:
            return ComponentStatus(self.FAILED_STATUS,
                                   reason='Keystore password file does not exist',
                                   error_message=f'File {keystore_password_path}'
                                                 f' does not exists')

        keystore_password = self._get_keystore_password(keystore_password_path)
        try:
            jks.KeyStore.load(keystore_path, keystore_password)
            return ComponentStatus(status=self.READY_STATUS)
        except Exception as keystore_exception:
            return ComponentStatus(status=self.FAILED_STATUS,
                                   reason='Keystore access failed',
                                   error_message=keystore_exception)

    @staticmethod
    def _get_keystore_password(keystore_password_path) -> str:
        keystore_password_file = open(keystore_password_path, 'r')
        keystore_password = keystore_password_file.readline()

        return Security().decrypt(keystore_password)
