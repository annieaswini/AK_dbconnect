from abc import ABC, abstractmethod
from .component_status import ComponentStatus


class Component(ABC):
    READY_STATUS = 'Ready'
    FAILED_STATUS = 'Failed'

    @abstractmethod
    def get_status(self, **kwargs) -> ComponentStatus:
        raise NotImplementedError
