import sys

from .component import Component
from ..configurations.connection_service import ConnectionService
from ..configurations.identity_service import IdentityService
from ..connections.connector_gateway import ConnectorGateway
from ..databases.db2 import Db2
from ..databases.mssql import MsSql
from ..databases.mysql import MySql
from ..databases.oracle import Oracle
from ..databases.postgresql import PostgreSql
from ..databases.redshift import Redshift
from ..databases.snowflake import Snowflake


class Connection(Component):

    def __init__(self, connection_service: ConnectionService,
                 identity_service: IdentityService,
                 connector_gateway: ConnectorGateway):
        self._connection_service = connection_service
        self._identity_service = identity_service
        self._connector_gateway = connector_gateway

    def get_status(self, **kwargs):
        connection_name = kwargs.get('connection_name')

        try:
            connection_conf = self._connection_service.get_connection_conf(
                connection_name)
            identity_conf = self._identity_service.get_identity_conf(
                connection_conf.identity)
            database = self._get_database(connection_conf.connection_type)

            return database.get_status(connection_conf, identity_conf)

        except Exception as connection_not_found:
            print(
                f'An error occurred while trying to get the connection with '
                f'the name : {connection_name}. '
                f'Error message: {connection_not_found}')
            sys.exit()

    def _get_database(self, connection_type):
        if connection_type == 'mysql':
            database = MySql(self._connector_gateway)
        elif connection_type == 'oracle':
            database = Oracle(self._connector_gateway)
        elif connection_type == 'generic_mssql':
            database = MsSql(self._connector_gateway)
        elif connection_type == 'postgres':
            database = PostgreSql(self._connector_gateway)
        elif connection_type == 'snowflake':
            database = Snowflake(self._connector_gateway)
        elif connection_type == 'db2':
            database = Db2(self._connector_gateway)
        elif connection_type == 'redshift':
            database = Redshift(self._connector_gateway)
        else:
            print(f'Connection type: {connection_type} is '
                  f'not supported!')
            sys.exit()

        return database
