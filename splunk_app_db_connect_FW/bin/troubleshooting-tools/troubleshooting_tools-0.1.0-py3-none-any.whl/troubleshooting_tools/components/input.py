import sys

from .component import Component
from .component_status import ComponentStatus
from .connection import Connection
from ..configurations.kv_store_service import KvStoreService
from .http_event_collector import HttpEventCollector
from .kv_store import KvStore
from ..configurations.input_service import InputService


class Input(Component):
    _CHECKPOINT_COLLECTION = 'dbx_db_input'

    def __init__(self, input_service: InputService, connection: Connection,
                 http_event_collector: HttpEventCollector, kv_store: KvStore,
                 kv_store_service: KvStoreService):
        self._input_service = input_service
        self._connection = connection
        self._http_event_collector = http_event_collector
        self._kv_store = kv_store
        self._kv_store_service = kv_store_service

    def get_status(self, **kwargs):
        input_name = kwargs.get('input_name')

        try:
            input_conf = self._input_service.get_input_conf(input_name)

            connection_status = self._get_connection_status(
                input_conf.connection)
            if connection_status.status == Component.FAILED_STATUS:
                return connection_status

            hec_status = self._get_hec_status()
            if hec_status.status == Component.FAILED_STATUS:
                return hec_status

            if input_conf.mode == 'rising':
                kv_store_status = self._get_kv_store_status()
                if kv_store_status.status == Component.FAILED_STATUS:
                    return kv_store_status

                checkpoint_status = self._get_checkpoint_status(
                    input_conf.checkpoint_key)
                if checkpoint_status.status == Component.FAILED_STATUS:
                    return checkpoint_status

            return ComponentStatus(status=Component.READY_STATUS)

        except Exception as input_not_found:
            print(
                f'An error occurred while trying to get the input with '
                f'the name : {input_name}. '
                f'Error message: {input_not_found}')
            sys.exit()

    def _get_connection_status(self, connection_name):
        connection_status = self._connection.get_status(
            connection_name=connection_name)

        if connection_status.status == Component.FAILED_STATUS:
            return ComponentStatus(status=Component.FAILED_STATUS,
                                   reason='Connection can not be established',
                                   error_message=connection_status.error_message)

        return ComponentStatus(status=Component.READY_STATUS)

    def _get_hec_status(self):
        hec_status = self._http_event_collector.get_status()

        if hec_status.status == Component.FAILED_STATUS:
            return ComponentStatus(status=Component.FAILED_STATUS,
                                   reason='HEC is unavailable',
                                   error_message=hec_status.error_message)

        return ComponentStatus(status=Component.READY_STATUS)

    def _get_kv_store_status(self):
        kv_store_status = self._kv_store.get_status()

        if kv_store_status.status == Component.FAILED_STATUS:
            return ComponentStatus(status=Component.FAILED_STATUS,
                                   reason='KV Store is unavailable',
                                   error_message=kv_store_status.error_message)

        return ComponentStatus(status=Component.READY_STATUS)

    def _get_checkpoint_status(self, checkpoint_key):
        checkpoint = self._kv_store_service.get_value(
            self._CHECKPOINT_COLLECTION,
            checkpoint_key)
        if checkpoint is None:
            return ComponentStatus(status=Component.FAILED_STATUS,
                                   reason='Checkpoint is not present in the KV Store',
                                   error_message=f'Checkpoint with key {checkpoint_key} is not present in the KV Store')

        return ComponentStatus(status=Component.READY_STATUS)
