from .component import Component
from .component_status import ComponentStatus
from time import sleep


class SearchApi(Component):

    def __init__(self, splunk_service):
        self._splunk_service = splunk_service

    def get_status(self) -> ComponentStatus:
        max_attempts = 10
        attempts = 0
        job = self._splunk_service.jobs.create('search * | head 10',
                                               exec_mode='normal')
        while (not job.is_ready()) & (attempts < max_attempts):
            attempts += 1
            sleep(2)

        if job.is_ready():
            return ComponentStatus(status=self.READY_STATUS)
        else:
            return ComponentStatus(status=self.FAILED_STATUS,
                                   reason="Search API is not available")
