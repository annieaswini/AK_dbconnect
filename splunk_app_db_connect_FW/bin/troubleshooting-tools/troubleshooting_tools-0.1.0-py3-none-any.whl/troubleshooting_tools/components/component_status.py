class ComponentStatus:

    def __init__(self, status=None, reason=None, error_message=None):
        self.status = status
        self.reason = reason
        self.error_message = error_message

