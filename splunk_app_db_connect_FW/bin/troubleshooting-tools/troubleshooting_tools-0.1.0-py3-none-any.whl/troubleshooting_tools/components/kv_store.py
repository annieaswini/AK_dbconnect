from .component import Component
from .component_status import ComponentStatus


class KvStore(Component):

    def __init__(self, splunk_service):
        self._splunk_service = splunk_service

    def get_status(self) -> ComponentStatus:
        is_enabled = self._is_enabled()
        if not is_enabled:
            return ComponentStatus(status=self.FAILED_STATUS,
                                   reason='KV Store is not enabled')

        is_ready = self._is_ready()
        if not is_ready:
            return ComponentStatus(status=self.FAILED_STATUS,
                                   reason='KV Store is enabled but is is not '
                                          'ready')

        return ComponentStatus(status=self.READY_STATUS)

    def _is_enabled(self) -> bool:
        kv_store_disabled = self._splunk_service.settings.content['kvStoreDisabled']
        return kv_store_disabled == '0'

    def _is_ready(self) -> bool:
        server_info = self._splunk_service.info
        return server_info['kvStoreStatus'] == 'ready'
