import os
import subprocess

from .component import Component
from .component_status import ComponentStatus
from ..configurations.settings_service import SettingsService


class Java(Component):
    _JAVA_HOME_VAR = 'JAVA_HOME'

    def __init__(self, settings: SettingsService):
        self._settings = settings

    def get_status(self) -> ComponentStatus:
        java_as_environment_variable_status = self._get_java_as_environment_variable_status()
        java_in_settings_status = self._get_java_in_settings_status()

        if java_in_settings_status.status == self.FAILED_STATUS:
            return java_in_settings_status

        if java_as_environment_variable_status.status == self.FAILED_STATUS:
            return java_as_environment_variable_status

        return ComponentStatus(self.READY_STATUS)

    def _get_java_as_environment_variable_status(self) -> ComponentStatus:
        java_home = os.getenv(self._JAVA_HOME_VAR)

        if java_home is not None:
            is_java_home_valid = self._is_java_home_valid(java_home)
            if is_java_home_valid:
                return ComponentStatus(status=self.READY_STATUS)
            else:
                return ComponentStatus(status=self.FAILED_STATUS,
                                       reason='JAVA_HOME is presents, but it '
                                              'contains a wrong path')

        return ComponentStatus(status=self.FAILED_STATUS,
                               reason='JAVA_HOME is not presents')

    def _get_java_in_settings_status(self) -> ComponentStatus:
        java_home = self._settings.get_java_home()

        if java_home is not None:
            is_java_home_valid = self._is_java_home_valid(java_home)
            if is_java_home_valid:
                return ComponentStatus(status=self.READY_STATUS)
            else:
                return ComponentStatus(status=self.FAILED_STATUS,
                                       reason='JRE Installation Path is '
                                              'presents, but it contains a '
                                              'wrong path')

        return ComponentStatus(status=self.FAILED_STATUS,
                               reason='JRE Installation Path is not presents')

    @staticmethod
    def _is_java_home_valid(java_home) -> bool:
        java_home_exists = os.path.exists(java_home)
        is_valid_location = False

        if java_home_exists:
            java_executable = os.path.join(java_home, 'bin', 'java')
            output = subprocess.run(f'{java_executable} --version',
                                    shell=True, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE)
            is_valid_location = output.returncode == 0

        return is_valid_location
