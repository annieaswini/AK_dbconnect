import os
import configparser
from configparser import ConfigParser
from typing import Optional


class SplunkSettingsService:
    _SPLUNK_HOME_VAR = 'SPLUNK_HOME'
    _WEB_SETTINGS_SECTION = "settings"
    _WEB_SETTINGS_HOST_PORT_PROPERTY = "mgmtHostPort"
    _SYSTEM_WEB_DEFAULT = os.path.join('etc', 'system', 'default', 'web.conf')
    _SYSTEM_WEB_LOCAL = os.path.join('etc', 'system', 'local', 'web.conf')

    def __init__(self):
        self._splunk_home = os.getenv(self._SPLUNK_HOME_VAR)

    def get_management_port(self) -> str:
        local_web_path = os.path.join(self._splunk_home, self._SYSTEM_WEB_LOCAL)
        port_from_local = self._get_management_port(local_web_path)
        if not port_from_local:
            default_web_path = os.path.join(self._splunk_home,
                                            self._SYSTEM_WEB_DEFAULT)
            return self._get_management_port(default_web_path)

        return port_from_local

    def _get_management_port(self, web_path) -> Optional[str]:
        if os.path.exists(web_path):
            try:
                config = ConfigParser()
                config.read(web_path)
                host_port = config.get(self._WEB_SETTINGS_SECTION,
                                       self._WEB_SETTINGS_HOST_PORT_PROPERTY)
                if host_port:
                    return host_port.split(':')[1]
            except (configparser.NoOptionError, configparser.NoSectionError):
                return None
