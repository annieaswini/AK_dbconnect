class KvStoreService:

    def __init__(self, splunk_service):
        self._splunk_service = splunk_service

    def get_value(self, collection_name, key):
        try:
            collection = self._splunk_service.kvstore[collection_name]
            data = collection.data.query_by_id(key)
            return data

        except Exception:
            return None
