class IdentityConf:

    def __init__(self, username=None, password=None):
        self.username = username
        self.password = password
