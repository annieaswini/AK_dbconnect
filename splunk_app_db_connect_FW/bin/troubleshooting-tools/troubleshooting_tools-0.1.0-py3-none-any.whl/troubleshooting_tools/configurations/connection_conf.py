class ConnectionConf:

    def __init__(self, connection_properties=None, connection_type=None,
                 database=None, disabled=None, host=None, identity=None,
                 jdbc_use_ssl=None, port=None, readonly=None, timezone=None,
                 customized_jdbc_url=None, certificate=None):
        self.connection_properties = connection_properties
        self.connection_type = connection_type
        self.database = database
        self.disabled = disabled
        self.host = host
        self.identity = identity
        self.jdbc_use_ssl = jdbc_use_ssl
        self.port = port
        self.readonly = readonly
        self.timezone = timezone
        self.customized_jdbc_url = customized_jdbc_url
        self.certificate = certificate
