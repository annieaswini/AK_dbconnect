import splunklib.client as splunk_client

from .input_conf import InputConf


class InputService:
    _INPUT_CONF_API = 'configs/conf-db_inputs'

    def __init__(self, splunk_service):
        self._splunk_service = splunk_service

    def get_input_conf(self, input_name) -> InputConf:
        input_conf_api = f'{self._INPUT_CONF_API}/{input_name}'
        response = splunk_client.Entity(self._splunk_service,
                                        input_conf_api).content
        connection = response.get('connection')
        mode = response.get('mode')
        checkpoint_key = response.get('checkpoint_key')

        return InputConf(connection=connection, mode=mode,
                         checkpoint_key=checkpoint_key)
