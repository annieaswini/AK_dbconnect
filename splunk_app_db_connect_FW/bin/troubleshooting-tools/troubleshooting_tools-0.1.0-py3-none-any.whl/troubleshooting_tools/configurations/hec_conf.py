class HecConf:

    def __init__(self, hosts=None, port=None, token=None, disabled=None):
        self.hosts = hosts
        self.port = port
        self.token = token
        self.disabled = disabled
