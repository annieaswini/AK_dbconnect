class InputConf:

    def __init__(self, connection=None, mode=None, checkpoint_key=None):
        self.connection = connection
        self.mode = mode
        self.checkpoint_key = checkpoint_key
