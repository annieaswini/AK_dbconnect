class ConfigurationError(Exception):

    def __init__(self, reason=None, message=None):
        self.reason = reason
        self.message = message

    def __str__(self):
        if self.message is not None:
            return self.message

        return self.reason
