import splunklib.client as splunk_client

from .hec_conf import HecConf
from .configuration_error import ConfigurationError


class HttpInputsService:
    _HTTP_CONF_API = 'data/inputs/http'

    def __init__(self, splunk_service):
        self._splunk_service = splunk_service

    def get_global_hec_conf(self) -> HecConf:
        try:
            hec_conf_api = f'{self._HTTP_CONF_API}/http'
            response = splunk_client.Entity(self._splunk_service,
                                            hec_conf_api).content
            port = response.get('port')
            disabled = response.get('disabled')

            return HecConf(port=port, disabled=disabled)

        except Exception as error:
            raise ConfigurationError(reason='Global HEC is not configured',
                                     message=error)

    def get_hec_token_conf(self) -> HecConf:
        try:
            hec_conf_api = f'{self._HTTP_CONF_API}/db-connect-http-input'
            response = splunk_client.Entity(self._splunk_service,
                                            hec_conf_api).content
            token = response.get('token')
            disabled = response.get('disabled')

            return HecConf(token=token, disabled=disabled)

        except Exception as error:
            raise ConfigurationError(reason='HEC token is not configured',
                                     message=error)
