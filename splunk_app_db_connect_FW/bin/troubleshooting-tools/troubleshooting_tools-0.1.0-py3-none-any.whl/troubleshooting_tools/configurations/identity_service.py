import splunklib.client as splunk_client

from .identity_conf import IdentityConf
from ..security.security import Security


class IdentityService:
    _IDENTITY_CONF_API = 'configs/conf-identities'

    def __init__(self, splunk_service):
        self._splunk_service = splunk_service

    def get_identity_conf(self, identity_name) -> IdentityConf:
        identity_conf_api = f'{self._IDENTITY_CONF_API}/{identity_name}'
        response = splunk_client.Entity(self._splunk_service,
                                        identity_conf_api).content
        username = response.get('username')
        password = response.get('password')

        return IdentityConf(username=username,
                            password=Security().decrypt(password))
