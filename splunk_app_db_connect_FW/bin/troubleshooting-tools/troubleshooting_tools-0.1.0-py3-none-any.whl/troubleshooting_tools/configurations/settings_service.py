import splunklib.client as splunk_client

from .hec_conf import HecConf


class SettingsService:
    _SETTINGS_CONF_API = 'configs/conf-dbx_settings'

    def __init__(self, splunk_service):
        self._splunk_service = splunk_service

    def get_java_home(self) -> str:
        java_conf_api = f'{self._SETTINGS_CONF_API}/java'
        response = splunk_client.Entity(self._splunk_service,
                                        java_conf_api).content
        java_home = response.get('javaHome')

        return java_home

    def get_hec_conf(self) -> HecConf:
        hec_conf_api = f'{self._SETTINGS_CONF_API}/hec'
        response = splunk_client.Entity(self._splunk_service,
                                        hec_conf_api).content
        hec_uris = response.get('hecUris')
        hec_tokens = response.get('hecToken')

        return HecConf(hosts=hec_uris, token=hec_tokens)
