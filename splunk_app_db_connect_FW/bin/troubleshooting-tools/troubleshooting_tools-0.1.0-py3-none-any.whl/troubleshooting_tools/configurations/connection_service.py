import splunklib.client as splunk_client

from .connection_conf import ConnectionConf


class ConnectionService:
    _CONNECTION_CONF_API = 'configs/conf-db_connections'

    def __init__(self, splunk_service):
        self._splunk_service = splunk_service

    def get_connection_conf(self, connection_name) -> ConnectionConf:
        connection_conf_api = f'{self._CONNECTION_CONF_API}/{connection_name}'
        response = splunk_client.Entity(self._splunk_service,
                                        connection_conf_api).content
        connection_properties = response.get('connection_properties')
        connection_type = response.get('connection_type')
        database = response.get('database')
        disabled = response.get('disabled')
        host = response.get('host')
        identity = response.get('identity')
        jdbc_use_ssl = response.get('jdbcUseSSL')
        port = response.get('port')
        readonly = response.get('readonly')
        timezone = response.get('timezone')
        customized_jdbc_url = response.get('customizedJdbcUrl')
        certificate = response.get('certificate')

        return ConnectionConf(connection_properties=connection_properties,
                              connection_type=connection_type,
                              database=database, disabled=disabled, host=host,
                              identity=identity, jdbc_use_ssl=jdbc_use_ssl,
                              port=port,
                              readonly=readonly, timezone=timezone,
                              customized_jdbc_url=customized_jdbc_url,
                              certificate=certificate)
